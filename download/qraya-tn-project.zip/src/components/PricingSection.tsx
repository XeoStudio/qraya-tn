'use client'

import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Check, Star, Crown, Zap } from 'lucide-react'

interface PricingSectionProps {
  onContact: () => void
}

const plans = [
  {
    id: 'basic',
    name: 'أساسي',
    nameEn: 'BASIC',
    price: '9.99',
    currency: 'DT',
    period: '/شهري',
    description: 'للطلاب الذين يريدون ميزات إضافية',
    icon: Zap,
    color: 'from-blue-500 to-blue-600',
    popular: false,
    features: [
      'وضع المعلم الذكي',
      '50 محادثة يومياً',
      'استخراج نصوص من الصور',
      'دعم عبر الرسائل',
      'تلخيص المحتوى'
    ]
  },
  {
    id: 'premium',
    name: 'ممتاز',
    nameEn: 'PREMIUM',
    price: '19.99',
    currency: 'DT',
    period: '/شهري',
    description: 'الأكثر شعبية - كل شيء غير محدود',
    icon: Star,
    color: 'from-purple-500 to-purple-600',
    popular: true,
    features: [
      'جميع مميزات الأساسي',
      'محادثات غير محدودة',
      'ذكاء اصطناعي متقدم',
      'أولوية في الرد',
      'تصدير PDF',
      'خطط دراسة مخصصة'
    ]
  },
  {
    id: 'lifetime',
    name: 'مدى الحياة',
    nameEn: 'LIFETIME',
    price: '99.99',
    currency: 'DT',
    period: 'لمرة واحدة',
    description: 'اشتراك لمرة واحدة للأبد',
    icon: Crown,
    color: 'from-amber-500 to-amber-600',
    popular: false,
    features: [
      'جميع مميزات الممتاز',
      'تحديثات مجانية للأبد',
      'دعم أولوية VIP',
      'خطط دراسة مخصصة',
      'OCR غير محدود',
      'وصول مبكر للميزات الجديدة'
    ]
  }
]

export default function PricingSection({ onContact }: PricingSectionProps) {
  return (
    <section className="py-20 bg-white dark:bg-gray-800" id="pricing">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            خطط الاشتراك
          </h2>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            اختر الخطة المناسبة لك. جميع الخطط تأتي مع ضمان استرداد المال خلال 7 أيام.
          </p>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative ${plan.popular ? 'md:-translate-y-4' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  الأكثر شعبية
                </div>
              )}
              <Card className={`p-6 border-0 shadow-lg hover:shadow-xl transition-all duration-300 h-full ${
                plan.popular 
                  ? 'bg-gradient-to-b from-purple-50 to-white dark:from-purple-900/20 dark:to-gray-800 ring-2 ring-purple-500' 
                  : 'bg-white dark:bg-gray-800'
              }`}>
                {/* Icon */}
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-r ${plan.color} flex items-center justify-center mb-4`}>
                  <plan.icon className="w-7 h-7 text-white" />
                </div>

                {/* Plan Name */}
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">
                  {plan.name}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  {plan.description}
                </p>

                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">
                    {plan.price}
                  </span>
                  <span className="text-gray-500 dark:text-gray-400 mr-1">
                    {plan.currency}
                  </span>
                  <span className="text-gray-500 dark:text-gray-400">
                    {plan.period}
                  </span>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                      <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <Button
                  onClick={onContact}
                  className={`w-full ${
                    plan.popular
                      ? `bg-gradient-to-r ${plan.color} hover:opacity-90`
                      : 'bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600'
                  } text-white rounded-xl py-6`}
                >
                  اشترك الآن
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Contact Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12 p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl max-w-2xl mx-auto"
        >
          <p className="text-gray-600 dark:text-gray-400 mb-2">
            للتواصل والاشتراك عبر واتساب
          </p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white" dir="ltr">
            +216 24 239 724
          </p>
        </motion.div>
      </div>
    </section>
  )
}
